import sys, os
# from utils.file import parse
import matplotlib.pyplot as plt
from glob import glob
import numpy as np
from tqdm import trange
import pandas as pd


ingestion_program = sys.argv[1] 
train_data = sys.argv[2] 
output_dir = sys.argv[3] 
input_dir = sys.argv[4] 
#shared_directory = sys.argv[5]
submission_program = sys.argv[5] 

sys.path.append(submission_program)

import submission_model



# Read data
train_X_path = os.path.join(train_data, 'data_train_X.csv')
train_y_path = os.path.join(train_data, 'data_train_target.npy')
test_path = os.path.join(train_data, 'data_test_X.csv')

X = pd.read_csv(train_X_path)
y = np.load(train_y_path)

# Train model and find the best hyperparameters
model = submission_model.Model()
model.fit(X, y)

X_test = pd.read_csv(test_path) # load
preds_test = model.predict_proba(X_test)[:,1]

preds_path = os.path.join(output_dir, "pred.csv")
np.savetxt(preds_path, preds_test)