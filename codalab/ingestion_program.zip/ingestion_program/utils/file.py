import numpy as np
import pandas as pd
import numpy as np


def parse(filename, train=True):
    with open(filename) as f:
        if train: header = f.readline()
        energy_bins = [float(x) for x in f.readline().split(' ')] # бины спектра
        entries_1 = [int(float(x)) for x in f.readline().split(' ')] # спектр с ближнего детектора
        entries_2 = [int(float(x)) for x in f.readline().split(' ')] # спектр с дальнего детектора
    assert(len(energy_bins) == len(entries_1) == len(entries_2), 'Bins number mismatch')
    bins = len(energy_bins)
#     values = np.concatenate([energy_bins, entries_1, entries_2])
#     names = ['bin_%d'%i for i in range(bins)] + ['detector_1_%d'%i for i in range(bins)] + ['detector_2_%d'%i for i in range(bins)]
    values = np.concatenate([entries_1, entries_2])
    names = ['detector_1_bin_%d'%i for i in range(bins)] + ['detector_2_bin_%d'%i for i in range(bins)]
    X = pd.DataFrame(values.reshape(1,2*bins), columns=names)
    if train: 
        label = int('oil' in header.lower())
        return X, label
    else: return X