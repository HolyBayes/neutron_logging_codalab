from sklearn.metrics import precision_recall_curve, auc
import numpy as np

def pr_auc(y_test, y_pred, recall_thresh=0.8):
    precision, recall, thresholds = precision_recall_curve(y_test, y_pred)
    indx = np.argsort(1-precision)
    indx = indx[recall[indx]>recall_thresh]
    if len(indx) < 2: return 0
    return auc(1-precision[indx], recall[indx])