import numpy as np
import pandas as pd
import sys
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_curve, auc

def pr_auc(y_test, y_pred, recall_thresh=0.8):
    precision, recall, thresholds = precision_recall_curve(y_test, y_pred)
    indx = np.argsort(1-precision)
    indx = indx[recall[indx]>recall_thresh]
    if len(indx) < 2: return 0
    return auc(1-precision[indx], recall[indx])

class Model:
    def preprocess(self,X):
        res = X.copy()
        res.iloc[:,:500]/=1.0*res.ix[:,:500].values.sum(1,keepdims=True) # normalize first spectrum
        res.iloc[:,500:]/=1.0*res.ix[:,500:].values.sum(1,keepdims=True) # normalize second spectrum
        res.fillna(0,inplace=True)
        return res

    
    def fit(self, X, y):
        X = self.preprocess(X)
        # Search for the best parameters
        Cs = []
        for _ in range(20):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8)
            clf = Pipeline([('preprocessing', StandardScaler()), 
                            ('model', LogisticRegressionCV(Cs=100, max_iter=10000))])
            clf.fit(X_train, y_train)
            Cs.append(clf.steps[-1][1].C_[0])

        metrics, accs = [], []
        y_tests, y_preds = [], []
        # Test the best parameters
        self.clf = Pipeline([('preprocessing', StandardScaler()), 
                        ('model', LogisticRegression(C=np.mean(Cs), max_iter=10000))])
        for _ in range(20):
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8)

            self.clf.fit(X_train, y_train)
            y_pred = self.clf.predict_proba(X_test)[:,1]
            y_preds.append(y_pred)
            y_tests.append(y_test)
        #     metric = roc_auc_score(y_test, y_pred)
            metric = pr_auc(y_test, y_pred)
            acc = accuracy_score(y_test, y_pred.round())
            metrics.append(metric), accs.append(acc)

        y_test, y_pred = np.concatenate(y_tests), np.concatenate(y_preds)


        # Train on all data
        self.clf.fit(X, y)

    def predict_proba(self, X):
        X = self.preprocess(X)
        return self.clf.predict_proba(X)