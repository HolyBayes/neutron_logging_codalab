import sys, os
import glob

import numpy as np
import pandas as pd

from sklearn.metrics import precision_recall_curve, auc
import numpy as np

def pr_auc(y_test, y_pred, recall_thresh=0.8):
    precision, recall, thresholds = precision_recall_curve(y_test, y_pred)
    indx = np.argsort(1-recall)
    indx = indx[recall[indx]>recall_thresh]
    if len(indx) < 2: return 0
    return auc(1-recall[indx], precision[indx])


input_dir = sys.argv[1]
output_dir = sys.argv[2]

submit_dir = os.path.join(input_dir, 'res')
reference_dir = os.path.join(input_dir, 'ref')

reference_file = os.path.join(reference_dir, 'data_test_target.npy')
files = glob.glob(submit_dir + "/*.csv")
prediction_file = files[0] 



if not os.path.isdir(submit_dir):
    print("{} doesn't exist".format(submit_dir))
elif not os.path.isdir(reference_dir):
    print("{} doesn't exist".format(reference_dir))
else:
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    y_pred = np.loadtxt(prediction_file)
    y = np.load(reference_file) # load
    score = pr_auc(y, y_pred)

   
    output_filename = os.path.join(output_dir, 'scores.txt')

    print("PR_AUC@0.8: {} \n".format(score))

    with open(output_filename, 'w') as output_file:
        output_file.write("PR_AUC@0.8: {}".format(score))

